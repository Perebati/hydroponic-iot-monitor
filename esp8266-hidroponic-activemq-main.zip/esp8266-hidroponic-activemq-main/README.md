# esp8266-hidroponic-activemq
Código feito para integrar servidor, aplicativo e microcontrolador através do broker ActiveMQ funcionando na AmazonMQ.
