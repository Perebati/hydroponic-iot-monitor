package com.example.demo.listener;

import com.example.demo.Events.alertaEvento;
import org.eclipse.paho.client.mqttv3.*;
import org.json.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;


public class ambienteListener {

    private static final String BROKER = "ssl://b-f3ef6eef-9bc8-426e-bb01-87b30b3421ed-1.mq.sa-east-1.amazonaws.com:8883";
    private static final String TOPIC = "esp8266_01/var_stream";
    private static final String USERNAME = "projetosistemas";
    private static final String PASSWORD = "projetosistemas";
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/trabSD";
    private static final String DB_USERNAME = "postgres";
    private static final String DB_PASSWORD = "admin";

    public static void main(String[] args) {
        try {
            System.out.println("Ouvindo Ambiente...");
            MqttClient mqttClient = new MqttClient(BROKER, MqttClient.generateClientId());
            MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
            mqttConnectOptions.setUserName(USERNAME);
            mqttConnectOptions.setPassword(PASSWORD.toCharArray());

            mqttClient.connect(mqttConnectOptions);
            mqttClient.subscribe(TOPIC);

            mqttClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable throwable) {
                    System.out.println("Ambiente: Conexão MQTT perdida");
                }

                @Override
                public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                    String message = new String(mqttMessage.getPayload());
                    if(streamAmbiente(message) == 1)
                    {
                        System.out.println("Ocorreu um erro na escrita no BD");
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
                    // Não utilizado no exemplo
                }
            });

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    public static int streamAmbiente(String message)
    {
        String jsonString = message;
        JSONObject obj = new JSONObject(jsonString);

        //Parsing
        String amb_id = obj.getString("amb_id");
        String tempAtual = obj.getString("temp_atual");
        String tempMin = obj.getString("temp_min");
        String tempMax = obj.getString("temp_max");
        String pH_Atual = obj.getString("ph_atual");
        String pH_Set = obj.getString("ph_target");
        String lum_Atual = obj.getString("lum_atual");

        //Checagem de temperatura e pH
        Integer tempCheck = Integer.valueOf(tempAtual);
        Integer tempmin = Integer.valueOf(tempMin);
        Integer tempmax = Integer.valueOf(tempMax);
        Integer pHAtual = Integer.valueOf(pH_Atual);
        Integer pHSet = Integer.valueOf(pH_Set);

        if(tempCheck > tempmax){
            alertaEvento.main(5, "Temperatura muito elevada!");
        }
        else if(tempCheck < tempmin)
        {
            alertaEvento.main(5, "Temperatura muito baixa!");
        }
        else if(pHAtual > (pHSet + 3)){
            alertaEvento.main(5, "pH muito alto!");
        }
        else if (pHAtual < (pHSet - 3)){
            alertaEvento.main(5, "pH muito baixo!");
        }

        //Data do registro
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String formattedDate = today.format(formatter);

        //Hora do registro
        LocalTime now = LocalTime.now();
        DateTimeFormatter tformatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String formattedTime = now.format(tformatter);

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            String sql =  "INSERT INTO ambiente VALUES " +
                    "('"+tempAtual+"','"+tempMin+"','"+tempMax+"','"+pH_Atual+"','"+pH_Set+"','"+lum_Atual+"','"+amb_id+"','"
                    +formattedDate+"','"+formattedTime+"')";
            System.out.println(sql);
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.executeUpdate();
            System.out.println("Log de ambiente registrado no banco de dados.");
            return 0;


        } catch (SQLException e) {
            e.printStackTrace();
            return 1;
        }
    }
}