package com.example.demo.listener;

import com.example.demo.Events.alertaEvento;
import org.eclipse.paho.client.mqttv3.*;
import org.json.*;
import java.sql.*;

public class loginListener {

    private static final String BROKER = "ssl://b-f3ef6eef-9bc8-426e-bb01-87b30b3421ed-1.mq.sa-east-1.amazonaws.com:8883";
    private static final String TOPIC_IN = "login_request";
    private static final String TOPIC_OUT = "login_reply";
    private static final String USERNAME = "projetosistemas";
    private static final String PASSWORD = "projetosistemas";
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/trabSD";
    private static final String DB_USERNAME = "postgres";
    private static final String DB_PASSWORD = "admin";

    public static void main(String[] args) {
        try {
            System.out.println("Ouvindo login...");
            MqttClient mqttClient = new MqttClient(BROKER, MqttClient.generateClientId());
            MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
            mqttConnectOptions.setUserName(USERNAME);
            mqttConnectOptions.setPassword(PASSWORD.toCharArray());

            mqttClient.connect(mqttConnectOptions);
            mqttClient.subscribe(TOPIC_IN);

            mqttClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable throwable) {
                    System.out.println("Conexão MQTT perdida");
                }

                @Override
                public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                    String message = new String(mqttMessage.getPayload());
                    System.out.println("Tentativa de login: " + message);
                    String login = verificarLogin(message);
                    if (login == "1") {
                        System.out.println("falha no login");
                        String mensagemErro= "{\"err_id\": \"3\", \"err_desc\": \"Usuario ou senha errado!\" }";
                        MqttMessage mqttMessageReturn = new MqttMessage(mensagemErro.getBytes());
                        mqttClient.publish(TOPIC_OUT, mqttMessageReturn);

                    } else {
                        System.out.println("Login bem sucedido");
                        alertaEvento.main(0, "Login bem sucedido");
                        MqttMessage mqttMessageReturn = new MqttMessage(login.getBytes());
                        mqttClient.publish(TOPIC_OUT, mqttMessageReturn);
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
                    // Não utilizado no exemplo
                }
            });

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public static String verificarLogin(String message) {
        String jsonString = message;
        JSONObject obj = new JSONObject(jsonString);

        String login = obj.getString("username");
        String senha = obj.getString("password");

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            String sql = "SELECT c.cli_id, e.equi_id, a.amb_id" +
                    " FROM usuario u, cliente c, equipamento e, ambiente_cli a" +
                    " WHERE u.user_id = c.user_key and" +
                    " u.email = \'" + login +
                    "\' AND u.senha = \'" + senha + "\' AND " +
                    "e.cli_id = c.cli_id AND" +
                    " a.ambCli_id = c.cli_id";
            //System.out.println(sql);
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet result = statement.executeQuery();
            System.out.println("Login verificado no banco de dados.");
            //System.out.println("Dados do BD:");
            while (result.next()) {
                String id_cli = result.getString("cli_id");
                String id_equi = result.getString("equi_id");
                String id_amb = result.getString("amb_id");
                String resp = "{\"cli_id\": \""+id_cli +
                        "\", \"equipamento\": \""+ id_equi +
                        "\", \"amb_id\": \""+ id_amb + "\"}";
                return resp;
            }


        } catch (SQLException e) {
            e.printStackTrace();

        }
        return "1";
    }
}