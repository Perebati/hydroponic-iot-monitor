package com.example.demo.listener;

import org.eclipse.paho.client.mqttv3.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class relatorioListener {

    private static final String BROKER = "ssl://b-f3ef6eef-9bc8-426e-bb01-87b30b3421ed-1.mq.sa-east-1.amazonaws.com:8883";
    private static final String TOPIC_IN = "relatorio_request";
    private static final String TOPIC_OUT = "relatorio_reply";
    private static final String USERNAME = "projetosistemas";
    private static final String PASSWORD = "projetosistemas";
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/trabSD";
    private static final String DB_USERNAME = "postgres";
    private static final String DB_PASSWORD = "admin";

    public static void main(String[] args) {
        try {
            System.out.println("Ouvindo Ambiente...");
            MqttClient mqttClient = new MqttClient(BROKER, MqttClient.generateClientId());
            MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
            mqttConnectOptions.setUserName(USERNAME);
            mqttConnectOptions.setPassword(PASSWORD.toCharArray());

            mqttClient.connect(mqttConnectOptions);
            mqttClient.subscribe(TOPIC_IN);

            mqttClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable throwable) {
                    System.out.println("Ambiente: Conexão MQTT perdida");
                }

                @Override
                public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                    String message = new String(mqttMessage.getPayload());
                    String retorno = relatorioAmbiente(message);
                    if (retorno == null) {
                        System.out.println("falha no login");
                    } else {
                        System.out.println("Login bem sucedido");
                        MqttMessage mqttMessageReturn = new MqttMessage(retorno.getBytes());
                        mqttClient.publish(TOPIC_OUT, mqttMessageReturn);
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
                    // Não utilizado no exemplo
                }
            });

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    public static String relatorioAmbiente(String message) throws ParseException {
        String jsonString = message;
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonObject = (JSONObject) jsonParser.parse(jsonString);

        //Data do registro
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String formattedDate = today.format(formatter);

        //Hora do registro
        LocalTime now = LocalTime.now();
        DateTimeFormatter tformatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String formattedTime = now.format(tformatter);

        //Parsing
        String cli_id = (String) jsonObject.get("cli_id");
        String ambid = (String) jsonObject.get("amb_id");
        String horainicial = (String) jsonObject.get("hora_inicial");
        String horafinal = (String) jsonObject.get("hora_final");
        String dataRef = (String) jsonObject.get("data_ref");

        //Consulta de dados para o relatorio
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            String sql = "SELECT tempAtual, phAtual, lumAtual FROM ambiente a WHERE a.amb_id = '"
                    + ambid + "' AND a.horaRegistro > '" + horainicial + "' AND a.horaRegistro < '" + horafinal + "' " +
                    "AND a.dataRegistro = '"+ dataRef + "'";
            System.out.println(sql);
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet result = statement.executeQuery();

            List<String> listTempAtual = new ArrayList<String>();
            List<String> listphAtual = new ArrayList<String>();
            List<String> listlumAtual = new ArrayList<String>();

            while (result.next()) {
                String tatual = result.getString("tempAtual");
                String phatual = result.getString("phAtual");
                String lumatual = result.getString("lumAtual");
                listTempAtual.add(tatual);
                listphAtual.add(phatual);
                listlumAtual.add(lumatual);
            }

            String retornoLum = ",\"lumAtual\": " + listlumAtual.toString() ;
            String retornoPH = ",\"phAtual\": " + listphAtual.toString() ;
            String retornoTemp = "\"tempAtual\": " + listTempAtual.toString();
            //Fim da consulta

            //Registro no BD da solititação do relatorio
            String sqlinsert =  "INSERT INTO relatorio_log VALUES " +
                    "('"+cli_id+"','"+ambid+"','"+formattedDate+"','"+formattedTime+"')";
            PreparedStatement statementInsert = connection.prepareStatement(sqlinsert);
            statementInsert.executeUpdate();

            //Envio dos dados para o relatório
            return "{" + retornoTemp + retornoPH + retornoLum + "}";

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}