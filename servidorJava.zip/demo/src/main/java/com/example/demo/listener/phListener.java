package com.example.demo.listener;

import org.eclipse.paho.client.mqttv3.*;
import org.json.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;


public class phListener {

    private static final String BROKER = "ssl://b-f3ef6eef-9bc8-426e-bb01-87b30b3421ed-1.mq.sa-east-1.amazonaws.com:8883";
    private static final String TOPIC = "10/ph_set";
    private static final String USERNAME = "projetosistemas";
    private static final String PASSWORD = "projetosistemas";
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/trabSD";
    private static final String DB_USERNAME = "postgres";
    private static final String DB_PASSWORD = "admin";

    public static void main(String[] args) {
        try {
            System.out.println("Ouvindo troca de pH...");
            MqttClient mqttClient = new MqttClient(BROKER, MqttClient.generateClientId());
            MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
            mqttConnectOptions.setUserName(USERNAME);
            mqttConnectOptions.setPassword(PASSWORD.toCharArray());

            mqttClient.connect(mqttConnectOptions);
            mqttClient.subscribe(TOPIC);

            mqttClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable throwable) {
                    System.out.println("phListener: Conexão MQTT perdida");
                }

                @Override
                public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                    String message = new String(mqttMessage.getPayload());
                    System.out.println(message);
                    if(ph_log_registro(message) == 1)
                    {
                        System.out.println("Ocorreu um erro na escrita no BD");
                    }

                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
                    // Não utilizado no exemplo
                }
            });

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    public static int ph_log_registro(String message)
    {
        String jsonString = message;
        JSONObject obj = new JSONObject(jsonString);

        //Parsing
        String cli_id = obj.getString("cli_id");
        String amb_id = obj.getString("amb_id");
        String pH_Set = obj.getString("ph_target");

        //Data do registro
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String formattedDate = today.format(formatter);

        //Hora do registro
        LocalTime now = LocalTime.now();
        DateTimeFormatter tformatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String formattedTime = now.format(tformatter);

        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD)) {
            String sql =  "INSERT INTO ph_log VALUES " +
                    "('"+pH_Set+"','"+formattedDate+"','"+formattedTime+"','"+amb_id+"','"+cli_id+"')";
            //System.out.println(sql);
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.executeUpdate();
            System.out.println("Log de de mudança de pH registrado no banco de dados.");
            return 0;


        } catch (SQLException e) {
            e.printStackTrace();
            return 1;
        }
    }
}